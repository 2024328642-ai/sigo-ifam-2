
import { NextResponse } from "next/server";
import { google } from "googleapis";
import path from "node:path";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export const runtime = "nodejs";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email || !session.user.role) {
    return NextResponse.json({ erro: "Não autenticado." }, { status: 401 });
  }

  try {
    const credentialsPath =
      process.env.GOOGLE_APPLICATION_CREDENTIALS;
    const spreadsheetId =
      process.env.GOOGLE_SHEETS_SPREADSHEET_ID;

    if (!credentialsPath || !spreadsheetId) {
      return NextResponse.json(
        { erro: "Configuração do Google Sheets ausente." },
        { status: 500 }
      );
    }

    const auth = new google.auth.GoogleAuth({
      keyFile: path.resolve(process.cwd(), credentialsPath),
      scopes: [
        "https://www.googleapis.com/auth/spreadsheets.readonly",
      ],
    });

    const sheets = google.sheets({ version: "v4", auth });

    const resposta = await sheets.spreadsheets.values.get({
      spreadsheetId,
      range: "Alunos!A1:F",
    });

    const linhas = resposta.data.values ?? [];
    const [, ...registros] = linhas;

    const alunos = registros.map((linha) => ({
      id: linha[0] ?? "",
      nome: linha[1] ?? "",
      matricula: linha[2] ?? "",
      turma: linha[3] ?? "",
      curso: linha[4] ?? "",
      ativo: linha[5] ?? "",
    }));

    return NextResponse.json({ alunos });
  } catch (erro) {
    console.error("Erro ao consultar alunos:", erro);

    return NextResponse.json(
      { erro: "Não foi possível consultar os alunos." },
      { status: 500 }
    );
  }
}
