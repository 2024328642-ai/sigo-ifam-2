import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { emailNormalizado, getSheets, perfilNormalizado } from "@/lib/sheets";
import { randomUUID } from "node:crypto";

export const runtime = "nodejs";

async function exigirDep() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email || session.user.role !== "dep") return null;
  return session;
}

export async function GET() {
  const session = await exigirDep();
  if (!session) return NextResponse.json({ erro: "Acesso restrito ao DEP." }, { status: 403 });

  try {
    const { sheets, spreadsheetId } = getSheets();
    const response = await sheets.spreadsheets.values.get({ spreadsheetId, range: "Usuarios!A1:E" });
    const rows = response.data.values ?? [];
    const [, ...users] = rows;
    return NextResponse.json({
      usuarios: users.map((r) => ({
        id: String(r[0] ?? ""),
        nome: String(r[1] ?? ""),
        email: String(r[2] ?? ""),
        perfil: String(r[3] ?? ""),
        ativo: String(r[4] ?? ""),
      })),
    });
  } catch (error) {
    console.error("Erro ao listar usuários:", error);
    return NextResponse.json({ erro: "Não foi possível consultar os usuários." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  const session = await exigirDep();
  if (!session) return NextResponse.json({ erro: "Apenas um administrador DEP pode cadastrar usuários." }, { status: 403 });

  try {
    const body = await request.json();
    const nome = typeof body.nome === "string" ? body.nome.trim() : "";
    const email = typeof body.email === "string" ? emailNormalizado(body.email) : "";
    const perfilSolicitado = typeof body.perfil === "string" ? body.perfil.trim() : "";
    const perfil = perfilNormalizado(perfilSolicitado);

    if (!nome || nome.length > 120 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json({ erro: "Informe nome e e-mail válidos." }, { status: 400 });
    }
    if (!perfil || !["assistente", "dep"].includes(perfil)) {
      return NextResponse.json({ erro: "Escolha o perfil Assistente de Alunos ou DEP." }, { status: 400 });
    }

    const { sheets, spreadsheetId } = getSheets();
    const response = await sheets.spreadsheets.values.get({ spreadsheetId, range: "Usuarios!A1:E" });
    const rows = response.data.values ?? [];
    const [, ...users] = rows;
    if (users.some((r) => emailNormalizado(String(r[2] ?? "")) === email)) {
      return NextResponse.json({ erro: "Já existe um cadastro com esse e-mail." }, { status: 409 });
    }

    await sheets.spreadsheets.values.append({
      spreadsheetId,
      range: "Usuarios!A:E",
      valueInputOption: "RAW",
      insertDataOption: "INSERT_ROWS",
      requestBody: {
        values: [[randomUUID(), nome, email, perfil === "dep" ? "DEP" : "Assistente de Alunos", "Sim"]],
      },
    });

    return NextResponse.json({ mensagem: "Usuário cadastrado. Ele poderá entrar após autenticar com essa conta Google." }, { status: 201 });
  } catch (error) {
    console.error("Erro ao cadastrar usuário:", error);
    return NextResponse.json({ erro: "Não foi possível cadastrar o usuário." }, { status: 500 });
  }
}
