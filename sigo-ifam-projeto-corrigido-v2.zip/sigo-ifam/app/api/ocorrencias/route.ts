
import { NextResponse } from "next/server";
import { google } from "googleapis";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export const runtime = "nodejs";

function obterConfiguracao() {
  const credentialsPath =
    process.env.GOOGLE_APPLICATION_CREDENTIALS;
  const spreadsheetId =
    process.env.GOOGLE_SHEETS_SPREADSHEET_ID;

  if (!credentialsPath || !spreadsheetId) {
    throw new Error("Configuração do Google Sheets ausente.");
  }

  const auth = new google.auth.GoogleAuth({
    keyFile: path.resolve(process.cwd(), credentialsPath),
    scopes: [
      "https://www.googleapis.com/auth/spreadsheets",
    ],
  });

  return {
    spreadsheetId,
    sheets: google.sheets({ version: "v4", auth }),
  };
}

function erroJson(mensagem: string, status: number) {
  return NextResponse.json(
    { error: mensagem },
    { status }
  );
}

// Consulta as ocorrências registradas na planilha.
export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email || !session.user.role) {
    return erroJson("Não autenticado.", 401);
  }

  try {
    const { spreadsheetId, sheets } = obterConfiguracao();

    const resposta = await sheets.spreadsheets.values.get({
      spreadsheetId,
      range: "Ocorrencias!A1:J",
    });

    const linhas = resposta.data.values ?? [];
    const [, ...registros] = linhas;

    const ocorrencias = registros.map((linha) => ({
      id: linha[0] ?? "",
      aluno_id: linha[1] ?? "",
      data_fato: linha[2] ?? "",
      horario: linha[3] ?? "",
      tipo: linha[4] ?? "",
      item: linha[5] ?? "",
      observacao: linha[6] ?? "",
      registrado_por: linha[7] ?? "",
      criado_em: linha[8] ?? "",
      status: linha[9] ?? "",
    }));

    return NextResponse.json({ ocorrencias });
  } catch (erro) {
    console.error("Erro ao consultar ocorrências:", erro);

    return erroJson(
      "Não foi possível consultar as ocorrências.",
      500
    );
  }
}

// Registra uma ocorrência na planilha.
export async function POST(request: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email || session.user.role !== "assistente") {
    return erroJson("Apenas Assistentes de Alunos autorizados podem registrar ocorrências.", 403);
  }

  try {
    let corpo: unknown;

    try {
      corpo = await request.json();
    } catch {
      return erroJson("O corpo da requisição não é JSON válido.", 400);
    }

    if (
      typeof corpo !== "object" ||
      corpo === null ||
      Array.isArray(corpo)
    ) {
      return erroJson("Os dados enviados são inválidos.", 400);
    }

    const dados = corpo as Record<string, unknown>;

    const texto = (campo: string): string =>
      typeof dados[campo] === "string"
        ? (dados[campo] as string).trim()
        : "";

    const aluno_id = texto("aluno_id");
    const data_fato = texto("data_fato");
    const horario = texto("horario");
    const tipo = texto("tipo");
    const item = texto("item");
    const observacao = texto("observacao");
    const registrado_por = String(session.user.name || session.user.email || "Usuário autorizado");

    if (
      !aluno_id ||
      !data_fato ||
      !horario ||
      !tipo ||
      !item ||
      !observacao
    ) {
      return erroJson(
        "Preencha aluno, data, horário, tipo, item e descrição.",
        400
      );
    }

    // Tipos correspondentes às opções do formulário.
    const tiposPermitidos = [
      "Comportamento",
      "Uniforme",
      "Frequência",
      "Uso de equipamento",
      "Outro",
    ];

    const itensPermitidos = [
      "Orientação",
      "Advertência verbal",
      "Advertência escrita",
      "Encaminhamento à coordenação",
      "Outro",
    ];

    if (
      !tiposPermitidos.includes(tipo) ||
      !itensPermitidos.includes(item)
    ) {
      return erroJson(
        "O tipo ou a providência selecionada é inválida.",
        400
      );
    }

    if (
      aluno_id.length > 100 ||
      observacao.length > 2000 ||
      registrado_por.length > 200
    ) {
      return erroJson(
        "Um ou mais campos ultrapassam o tamanho permitido.",
        400
      );
    }

    // Valida os formatos de data e horário.
    if (!/^\d{4}-\d{2}-\d{2}$/.test(data_fato)) {
      return erroJson("A data informada é inválida.", 400);
    }

    const dataVerificada = new Date(`${data_fato}T00:00:00Z`);

    if (
      Number.isNaN(dataVerificada.getTime()) ||
      dataVerificada.toISOString().slice(0, 10) !== data_fato
    ) {
      return erroJson("A data informada não existe.", 400);
    }

    if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(horario)) {
      return erroJson("O horário informado é inválido.", 400);
    }

    const { spreadsheetId, sheets } = obterConfiguracao();

    // Confere se o aluno existe na aba Alunos.
    const respostaAlunos = await sheets.spreadsheets.values.get({
      spreadsheetId,
      range: "Alunos!A1:F",
    });

    const linhasAlunos = respostaAlunos.data.values ?? [];
    const [, ...alunos] = linhasAlunos;

    const alunoExiste = alunos.some(
      (linha) => String(linha[0] ?? "").trim() === aluno_id
    );

    if (!alunoExiste) {
      return erroJson(
        "O aluno informado não foi encontrado na planilha.",
        400
      );
    }

    const id = randomUUID();
    const criado_em = new Date().toISOString();
    const status = "Registrada";

    // Ordem das colunas A até J da aba Ocorrencias.
    await sheets.spreadsheets.values.append({
      spreadsheetId,
      range: "Ocorrencias!A:J",
      valueInputOption: "RAW",
      insertDataOption: "INSERT_ROWS",
      requestBody: {
        values: [
          [
            id,
            aluno_id,
            data_fato,
            horario,
            tipo,
            item,
            observacao,
            registrado_por,
            criado_em,
            status,
          ],
        ],
      },
    });

    return NextResponse.json(
      {
        mensagem: "Ocorrência registrada com sucesso.",
        ocorrencia: {
          id,
          aluno_id,
          data_fato,
          horario,
          tipo,
          item,
          observacao,
          registrado_por,
          criado_em,
          status,
        },
      },
      { status: 201 }
    );
  } catch (erro) {
    console.error("Erro ao registrar ocorrência:", erro);

    return erroJson(
      "Não foi possível registrar a ocorrência. Confira a configuração e as permissões do Google Sheets.",
      500
    );
  }
}
