
"use client";

import {
  FormEvent,
  ReactNode,
  useCallback,
  useEffect,
  useMemo,
  useState,
} from "react";
import { signIn, signOut, useSession } from "next-auth/react";

type Page =
  | "Dashboard"
  | "Registrar ocorrência"
  | "Alunos"
  | "Ocorrências"
  | "Login";

type Role = "inspetor" | "dep";

type AlunoAPI = {
  id: string;
  nome: string;
  matricula: string;
  turma: string;
  curso: string;
  ativo: string;
};

type AlunoSelecionavel = AlunoAPI & {
  initials: string;
};

type OccAPI = {
  id: string;
  aluno_id: string;
  data_fato: string;
  horario: string;
  tipo: string;
  item: string;
  observacao: string;
  registrado_por: string;
  criado_em?: string;
  status: string;
};

type Occ = {
  id: string;
  date: string;
  time: string;
  studentId: string;
  student: string;
  turma: string;
  tipo: "Uniforme" | "Atraso";
  item: string;
  obs: string;
  by: string;
  status: string;
};

const APP_NAME = "SIGO";
const APP_TAGLINE = "Gestão de Ocorrências · IFAM";





const profiles: Record<
  Role,
  {
    name: string;
    first: string;
    initials: string;
    label: string;
    menu: Page[];
  }
> = {
  inspetor: {
    name: "Marcelo Silva",
    first: "Marcelo",
    initials: "MS",
    label: "Assistente de alunos / Inspetor",
    menu: [
      "Dashboard",
      "Registrar ocorrência",
      "Alunos",
      "Ocorrências",
    ],
  },
  dep: {
    name: "Juliana Martins",
    first: "Juliana",
    initials: "JM",
    label: "Departamento de Ensino (DEP)",
    menu: [
      "Dashboard",
      "Alunos",
      "Ocorrências",
    ],
  },
};

function hojeISO() {
  const data = new Date();
  return new Date(
    data.getTime() - data.getTimezoneOffset() * 60000
  )
    .toISOString()
    .slice(0, 10);
}

function horaAtual() {
  return new Date().toTimeString().slice(0, 5);
}

function normalizar(texto: string) {
  return (texto || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim();
}

function iniciais(nome: string) {
  return (nome || "Aluno")
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((parte) => parte[0])
    .join("")
    .toUpperCase();
}

function Icon({
  name,
}: {
  name: "grid" | "plus" | "users" | "clipboard" | "search" | "check" | "logout";
}) {
  const desenhos = {
    grid: (
      <>
        <rect x="3" y="3" width="7" height="7" rx="1" />
        <rect x="14" y="3" width="7" height="7" rx="1" />
        <rect x="3" y="14" width="7" height="7" rx="1" />
        <rect x="14" y="14" width="7" height="7" rx="1" />
      </>
    ),
    plus: <path d="M12 5v14M5 12h14" />,
    users: (
      <>
        <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
        <circle cx="8.5" cy="7" r="4" />
        <path d="M20 8v6M23 11h-6" />
      </>
    ),
    clipboard: (
      <>
        <rect x="5" y="4" width="14" height="17" rx="2" />
        <path d="M9 4V2h6v2M9 10h6M9 14h6M9 18h4" />
      </>
    ),
    search: (
      <>
        <circle cx="11" cy="11" r="7" />
        <path d="m20 20-4-4" />
      </>
    ),
    check: <path d="m5 12 4 4L19 6" />,
    logout: (
      <>
        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
        <path d="m16 17 5-5-5-5M21 12H9" />
      </>
    ),
  };

  return (
    <svg
      width="19"
      height="19"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {desenhos[name]}
    </svg>
  );
}

function Button({
  children,
  onClick,
  type = "button",
  disabled = false,
  variant = "primary",
}: {
  children: ReactNode;
  onClick?: () => void;
  type?: "button" | "submit";
  disabled?: boolean;
  variant?: "primary" | "secondary" | "ghost";
}) {
  return (
    <button
      className={`button button-${variant}`}
      onClick={onClick}
      type={type}
      disabled={disabled}
    >
      {children}
    </button>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="field">
      <span className="field-label">{label}</span>
      {children}
    </label>
  );
}

function Input({
  value,
  onChange,
  placeholder,
  type = "text",
  required = false,
}: {
  value?: string;
  onChange?: (valor: string) => void;
  placeholder?: string;
  type?: string;
  required?: boolean;
}) {
  return (
    <input
      className="input"
      value={value}
      onChange={(e) => onChange?.(e.target.value)}
      placeholder={placeholder}
      type={type}
      required={required}
    />
  );
}

function Badge({
  children,
  tone = "neutral",
}: {
  children: ReactNode;
  tone?: "neutral" | "success" | "warning" | "info";
}) {
  return (
    <span className={`badge badge-${tone}`}>
      <span className="badge-dot" />
      {children}
    </span>
  );
}

function Card({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return <div className={`card ${className}`}>{children}</div>;
}

function PageTitle({
  eyebrow,
  title,
  subtitle,
  action,
}: {
  eyebrow: string;
  title: string;
  subtitle: string;
  action?: ReactNode;
}) {
  return (
    <div className="page-title">
      <div>
        <span className="eyebrow">{eyebrow}</span>
        <h1>{title}</h1>
        <p>{subtitle}</p>
      </div>
      {action}
    </div>
  );
}

function StudentSearch({
  onSelect,
}: {
  onSelect: (aluno: AlunoSelecionavel) => void;
}) {
  const [alunos, setAlunos] = useState<AlunoSelecionavel[]>([]);
  const [busca, setBusca] = useState("");
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState("");

  useEffect(() => {
    let ativo = true;

    async function carregarAlunos() {
      try {
        const resposta = await fetch("/api/alunos");
        if (!resposta.ok) throw new Error("Não foi possível carregar os alunos.");

        const dados = await resposta.json();
        const lista: AlunoAPI[] = dados.alunos ?? [];

        if (ativo) {
          setAlunos(
            lista
              .filter((a) => normalizar(a.ativo) !== "nao")
              .map((a) => ({
                id: String(a.id),
                nome: a.nome,
                matricula: a.matricula,
                turma: a.turma,
                curso: a.curso,
                initials: iniciais(a.nome),
              }))
          );
        }
      } catch {
        if (ativo) setErro("Erro ao carregar alunos da planilha.");
      } finally {
        if (ativo) setCarregando(false);
      }
    }

    carregarAlunos();
    return () => {
      ativo = false;
    };
  }, []);

  const filtrados = useMemo(() => {
    const termo = normalizar(busca);
    if (!termo) return alunos;

    return alunos.filter((a) =>
      normalizar(`${a.nome} ${a.matricula} ${a.turma} ${a.curso}`).includes(termo)
    );
  }, [alunos, busca]);

  return (
    <Card>
      <Field label="Buscar aluno" htmlFor="buscar-aluno">
        <Input
          id="buscar-aluno"
          value={busca}
          onChange={(e) => setBusca(e.target.value)}
          placeholder="Nome, matrícula ou turma..."
        />
      </Field>

      {carregando && <p className="text-sm text-slate-500">Carregando alunos...</p>}
      {erro && <p className="text-sm text-red-600">{erro}</p>}

      {!carregando && !erro && filtrados.length === 0 && (
        <p className="py-4 text-sm text-slate-500">Nenhum aluno encontrado.</p>
      )}

      <div className="mt-3 space-y-2">
        {filtrados.slice(0, 8).map((aluno) => (
          <button
            key={aluno.id}
            type="button"
            onClick={() => onSelect(aluno)}
            className="flex w-full items-center gap-3 rounded-xl border border-slate-200 p-3 text-left transition hover:border-blue-400 hover:bg-blue-50"
          >
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-blue-100 text-sm font-bold text-blue-700">
              {aluno.initials}
            </span>
            <span className="min-w-0 flex-1">
              <span className="block truncate font-semibold text-slate-800">
                {aluno.nome}
              </span>
              <span className="block text-xs text-slate-500">
                Matrícula: {aluno.matricula} · Turma: {aluno.turma}
              </span>
            </span>
            <Icon name="check" className="text-blue-600" />
          </button>
        ))}
      </div>
    </Card>
  );
}

function OccurrenceForm({
  onAdd,
}: {
  onAdd: (ocorrencia: Omit<Occ, "id" | "by" | "status">) => Promise<void>;
}) {
  const [aluno, setAluno] = useState<AlunoSelecionavel | null>(null);
  const [data, setData] = useState(hojeISO());
  const [horario, setHorario] = useState(horaAtual());
  const [tipo, setTipo] = useState("Comportamento");
  const [item, setItem] = useState("Advertência verbal");
  const [observacao, setObservacao] = useState("");
  const [enviando, setEnviando] = useState(false);
  const [erro, setErro] = useState("");
  const [sucesso, setSucesso] = useState("");

  async function enviar(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setErro("");
    setSucesso("");

    if (!aluno) {
      setErro("Selecione um aluno antes de registrar.");
      return;
    }

    if (!observacao.trim()) {
      setErro("Descreva brevemente o que aconteceu.");
      return;
    }

    setEnviando(true);

    try {
      await onAdd({
        aluno_id: aluno.id,
        aluno: aluno.nome,
        turma: aluno.turma,
        data_fato: data,
        horario,
        tipo,
        item,
        observacao: observacao.trim(),
      });

      setSucesso("Ocorrência registrada com sucesso.");
      setAluno(null);
      setObservacao("");
    } catch (err) {
      setErro(
        err instanceof Error
          ? err.message
          : "Não foi possível registrar a ocorrência."
      );
    } finally {
      setEnviando(false);
    }
  }

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <div className="space-y-4">
        <PageTitle
          title="Registrar ocorrência"
          subtitle="Selecione o aluno e preencha os dados do registro."
        />
        <StudentSearch onSelect={setAluno} />

        {aluno && (
          <Card>
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
              Aluno selecionado
            </p>
            <p className="font-semibold text-slate-800">{aluno.nome}</p>
            <p className="text-sm text-slate-500">
              Matrícula: {aluno.matricula} · Turma: {aluno.turma}
            </p>
            <Button
              className="mt-3"
              variant="secondary"
              onClick={() => setAluno(null)}
            >
              Trocar aluno
            </Button>
          </Card>
        )}
      </div>

      <Card>
        <form onSubmit={enviar} className="space-y-4">
          <h2 className="text-lg font-bold text-slate-800">Dados da ocorrência</h2>

          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Data do fato" htmlFor="data-fato">
              <Input
                id="data-fato"
                type="date"
                value={data}
                onChange={(e) => setData(e.target.value)}
                required
              />
            </Field>

            <Field label="Horário" htmlFor="horario-fato">
              <Input
                id="horario-fato"
                type="time"
                value={horario}
                onChange={(e) => setHorario(e.target.value)}
                required
              />
            </Field>
          </div>

          <Field label="Tipo" htmlFor="tipo-ocorrencia">
            <select
              id="tipo-ocorrencia"
              value={tipo}
              onChange={(e) => setTipo(e.target.value)}
              className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2.5 text-sm outline-none focus:border-blue-500"
            >
              <option>Comportamento</option>
              <option>Uniforme</option>
              <option>Frequência</option>
              <option>Uso de equipamento</option>
              <option>Outro</option>
            </select>
          </Field>

          <Field label="Providência ou item" htmlFor="item-ocorrencia">
            <select
              id="item-ocorrencia"
              value={item}
              onChange={(e) => setItem(e.target.value)}
              className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2.5 text-sm outline-none focus:border-blue-500"
            >
              <option>Orientação</option>
              <option>Advertência verbal</option>
              <option>Advertência escrita</option>
              <option>Encaminhamento à coordenação</option>
              <option>Outro</option>
            </select>
          </Field>

          <Field label="Descrição" htmlFor="descricao-ocorrencia">
            <textarea
              id="descricao-ocorrencia"
              value={observacao}
              onChange={(e) => setObservacao(e.target.value)}
              placeholder="Descreva os fatos de forma objetiva..."
              rows={5}
              required
              className="w-full resize-y rounded-xl border border-slate-300 px-3 py-2.5 text-sm outline-none focus:border-blue-500"
            />
          </Field>

          {erro && (
            <p className="rounded-lg bg-red-50 p-3 text-sm text-red-700">{erro}</p>
          )}

          {sucesso && (
            <p className="rounded-lg bg-green-50 p-3 text-sm text-green-700">
              {sucesso}
            </p>
          )}

          <Button type="submit" disabled={enviando} className="w-full">
            {enviando ? "Registrando..." : "Registrar ocorrência"}
          </Button>
        </form>
      </Card>
    </div>
  );
}

function Students() {
  const [alunos, setAlunos] = useState<AlunoAPI[]>([]);
  const [busca, setBusca] = useState("");
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState("");

  useEffect(() => {
    let ativo = true;

    async function carregar() {
      try {
        const resposta = await fetch("/api/alunos");
        if (!resposta.ok) throw new Error("Falha ao consultar a planilha.");

        const dados = await resposta.json();
        if (ativo) setAlunos(dados.alunos ?? []);
      } catch {
        if (ativo) setErro("Não foi possível carregar os alunos do Google Sheets.");
      } finally {
        if (ativo) setCarregando(false);
      }
    }

    carregar();
    return () => {
      ativo = false;
    };
  }, []);

  const filtrados = useMemo(() => {
    const termo = normalizar(busca);
    return alunos.filter((aluno) =>
      normalizar(
        `${aluno.nome} ${aluno.matricula} ${aluno.turma} ${aluno.curso}`
      ).includes(termo)
    );
  }, [alunos, busca]);

  return (
    <div className="space-y-5">
      <PageTitle
        title="Alunos"
        subtitle="Lista consultada diretamente na planilha do Google Sheets."
      />

      <Card>
        <Field label="Pesquisar aluno" htmlFor="pesquisa-alunos">
          <Input
            id="pesquisa-alunos"
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
            placeholder="Nome, matrícula, turma ou curso..."
          />
        </Field>
      </Card>

      {carregando && <Card>Carregando alunos...</Card>}
      {erro && <Card><p className="text-sm text-red-600">{erro}</p></Card>}

      {!carregando && !erro && (
        <Card>
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-bold text-slate-800">Alunos cadastrados</h2>
            <Badge>{filtrados.length} encontrado(s)</Badge>
          </div>

          {filtrados.length === 0 ? (
            <p className="py-6 text-center text-sm text-slate-500">
              Nenhum aluno encontrado na planilha.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[600px] text-left text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-xs uppercase text-slate-500">
                    <th className="px-3 py-3">Nome</th>
                    <th className="px-3 py-3">Matrícula</th>
                    <th className="px-3 py-3">Turma</th>
                    <th className="px-3 py-3">Curso</th>
                    <th className="px-3 py-3">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {filtrados.map((aluno) => (
                    <tr key={aluno.id} className="border-b border-slate-100">
                      <td className="px-3 py-3 font-medium text-slate-800">{aluno.nome}</td>
                      <td className="px-3 py-3">{aluno.matricula}</td>
                      <td className="px-3 py-3">{aluno.turma}</td>
                      <td className="px-3 py-3">{aluno.curso}</td>
                      <td className="px-3 py-3">
                        <Badge>{normalizar(aluno.ativo) === "nao" ? "Inativo" : "Ativo"}</Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      )}
    </div>
  );
}

function Dashboard({
  alunos,
  ocorrencias,
  onNavigate,
}: {
  alunos: AlunoAPI[];
  ocorrencias: Occ[];
  onNavigate: (page: Page) => void;
}) {
  const hoje = hojeISO();
  const ocorrenciasHoje = ocorrencias.filter((o) => o.data_fato === hoje).length;
  const alunosAtivos = alunos.filter(
    (a) => normalizar(a.ativo) !== "nao"
  ).length;

  const recentes = [...ocorrencias]
    .sort((a, b) =>
      `${b.data_fato} ${b.horario}`.localeCompare(
        `${a.data_fato} ${a.horario}`
      )
    )
    .slice(0, 5);

  return (
    <div className="space-y-6">
      <PageTitle
        title="Dashboard"
        subtitle="Visão geral dos dados consultados pelo SIGO-IFAM."
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        <Card>
          <div className="flex items-center justify-between">
            <span className="text-sm text-slate-500">Alunos ativos</span>
            <Icon name="users" className="text-blue-600" />
          </div>
          <p className="mt-3 text-3xl font-bold text-slate-900">
            {alunosAtivos}
          </p>
          <p className="mt-1 text-xs text-slate-500">Dados da planilha de alunos</p>
        </Card>

        <Card>
          <div className="flex items-center justify-between">
            <span className="text-sm text-slate-500">Ocorrências registradas</span>
            <Icon name="clipboard" className="text-amber-600" />
          </div>
          <p className="mt-3 text-3xl font-bold text-slate-900">
            {ocorrencias.length}
          </p>
          <p className="mt-1 text-xs text-slate-500">Registros carregados do sistema</p>
        </Card>

        <Card>
          <div className="flex items-center justify-between">
            <span className="text-sm text-slate-500">Ocorrências de hoje</span>
            <Icon name="check" className="text-green-600" />
          </div>
          <p className="mt-3 text-3xl font-bold text-slate-900">
            {ocorrenciasHoje}
          </p>
          <p className="mt-1 text-xs text-slate-500">Considerando a data atual</p>
        </Card>
      </div>

      <Card>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-bold text-slate-800">Ações rápidas</h2>
            <p className="mt-1 text-sm text-slate-500">
              Acesse as principais funções do sistema.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button onClick={() => onNavigate("Registrar ocorrência")}>
              <Icon name="plus" />
              Registrar ocorrência
            </Button>
            <Button
              variant="secondary"
              onClick={() => onNavigate("Alunos")}
            >
              <Icon name="users" />
              Consultar alunos
            </Button>
          </div>
        </div>
      </Card>

      <Card>
        <div className="mb-4 flex items-center justify-between gap-3">
          <h2 className="text-lg font-bold text-slate-800">
            Ocorrências recentes
          </h2>
          <Button
            variant="secondary"
            onClick={() => onNavigate("Ocorrências")}
          >
            Ver todas
          </Button>
        </div>

        {recentes.length === 0 ? (
          <p className="py-6 text-center text-sm text-slate-500">
            Ainda não há ocorrências para exibir.
          </p>
        ) : (
          <div className="space-y-3">
            {recentes.map((o) => (
              <div
                key={o.id}
                className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-100 pb-3 last:border-0 last:pb-0"
              >
                <div>
                  <p className="font-semibold text-slate-800">{o.aluno}</p>
                  <p className="mt-1 text-sm text-slate-500">
                    {o.tipo} · {o.item}
                  </p>
                </div>
                <span className="text-xs text-slate-500">
                  {o.data_fato} · {o.horario}
                </span>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}

function Occurrences({ ocorrencias }: { ocorrencias: Occ[] }) {
  const [busca, setBusca] = useState("");
  const [filtroData, setFiltroData] = useState("");

  const filtradas = useMemo(() => {
    const termo = normalizar(busca);

    return ocorrencias
      .filter((o) => !filtroData || o.data_fato === filtroData)
      .filter((o) =>
        normalizar(
          `${o.aluno} ${o.aluno_id} ${o.turma} ${o.tipo} ${o.item} ${o.observacao} ${o.status}`
        ).includes(termo)
      )
      .sort((a, b) =>
        `${b.data_fato} ${b.horario}`.localeCompare(
          `${a.data_fato} ${a.horario}`
        )
      );
  }, [ocorrencias, busca, filtroData]);

  return (
    <div className="space-y-5">
      <PageTitle
        title="Ocorrências"
        subtitle="Consulte os registros carregados da planilha."
      />

      <Card>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Pesquisar" htmlFor="buscar-ocorrencias">
            <Input
              id="buscar-ocorrencias"
              value={busca}
              onChange={(e) => setBusca(e.target.value)}
              placeholder="Aluno, turma, tipo ou descrição..."
            />
          </Field>

          <Field label="Filtrar por data" htmlFor="filtrar-data">
            <Input
              id="filtrar-data"
              type="date"
              value={filtroData}
              onChange={(e) => setFiltroData(e.target.value)}
            />
          </Field>
        </div>
      </Card>

      <Card>
        <div className="mb-4 flex items-center justify-between gap-3">
          <h2 className="font-bold text-slate-800">Registros encontrados</h2>
          <Badge>{filtradas.length}</Badge>
        </div>

        {filtradas.length === 0 ? (
          <p className="py-8 text-center text-sm text-slate-500">
            Nenhuma ocorrência encontrada.
          </p>
        ) : (
          <div className="space-y-4">
            {filtradas.map((o) => (
              <article
                key={o.id}
                className="rounded-xl border border-slate-200 p-4"
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <h3 className="font-semibold text-slate-900">{o.aluno}</h3>
                    <p className="mt-1 text-xs text-slate-500">
                      Matrícula/ID: {o.aluno_id} · Turma: {o.turma || "Não informada"}
                    </p>
                  </div>
                  <Badge>{o.status || "Registrada"}</Badge>
                </div>

                <div className="mt-3 flex flex-wrap gap-2">
                  <Badge>{o.tipo}</Badge>
                  <Badge>{o.item}</Badge>
                </div>

                <p className="mt-3 whitespace-pre-wrap text-sm text-slate-700">
                  {o.observacao}
                </p>

                <p className="mt-3 text-xs text-slate-500">
                  Data: {o.data_fato} · Horário: {o.horario}
                </p>
              </article>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}

function Login() {
  const [erro, setErro] = useState("");

  return (
    <div className="mx-auto max-w-md py-10">
      <Card>
        <div className="mb-5 text-center">
          <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-blue-100 text-blue-700">
            <Icon name="clipboard" />
          </div>
          <h1 className="text-2xl font-bold text-slate-900">{APP_NAME}-IFAM</h1>
          <p className="mt-2 text-sm text-slate-500">{APP_TAGLINE}</p>
        </div>

        <p className="mb-4 rounded-xl bg-blue-50 p-3 text-sm text-blue-800">
          Entre com sua conta Google institucional cadastrada e ativa na aba Usuarios.
        </p>

        {erro && <p className="mb-4 rounded-xl bg-red-50 p-3 text-sm text-red-700">{erro}</p>}

        <button
          type="button"
          className="flex w-full items-center justify-center gap-3 rounded-xl border border-slate-300 bg-white px-4 py-3 font-semibold text-slate-700 hover:bg-slate-50"
          onClick={() => {
            setErro("");
            signIn("google", { callbackUrl: "/" }).catch(() => {
              setErro("Não foi possível iniciar o login Google. Confira a configuração OAuth.");
            });
          }}
        >
          <span className="text-lg font-bold text-blue-600">G</span>
          Entrar com Google
        </button>

        <p className="mt-4 text-center text-xs text-slate-500">
          Se seu acesso não estiver autorizado, solicite o cadastro ao administrador do DEP.
        </p>
      </Card>
    </div>
  );
}

function AppShell({ role }: { role: "assistente" | "dep" }) {
  const [pagina, setPagina] = useState<Page>("Dashboard");
  const [alunos, setAlunos] = useState<AlunoAPI[]>([]);
  const [ocorrencias, setOcorrencias] = useState<Occ[]>([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState("");
  const [menuAberto, setMenuAberto] = useState(false);

  const carregarDados = useCallback(async () => {
    setErro("");

    try {
      const [respostaAlunos, respostaOcorrencias] = await Promise.all([
        fetch("/api/alunos"),
        fetch("/api/ocorrencias"),
      ]);

      if (!respostaAlunos.ok) {
        throw new Error("Não foi possível carregar os alunos.");
      }

      if (!respostaOcorrencias.ok) {
        throw new Error("Não foi possível carregar as ocorrências.");
      }

      const dadosAlunos = await respostaAlunos.json();
      const dadosOcorrencias = await respostaOcorrencias.json();

      setAlunos(dadosAlunos.alunos ?? []);

      const lista: Occ[] = (dadosOcorrencias.ocorrencias ?? []).map(
        (o: OccAPI & { turma?: string }) => {
          const alunoEncontrado = (dadosAlunos.alunos ?? []).find(
            (a: AlunoAPI) => String(a.id) === String(o.aluno_id)
          );

          return {
            id: String(o.id),
            aluno_id: String(o.aluno_id ?? ""),
            aluno: alunoEncontrado?.nome ?? `Aluno ID ${o.aluno_id ?? "não informado"}`,
            turma: alunoEncontrado?.turma ?? "",
            data_fato: o.data_fato ?? "",
            horario: o.horario ?? "",
            tipo: o.tipo ?? "",
            item: o.item ?? "",
            observacao: o.observacao ?? "",
            status: o.status ?? "Registrada",
            by: o.registrado_por ?? "",
          };
        }
      );

      setOcorrencias(lista);
    } catch (err) {
      setErro(
        err instanceof Error
          ? err.message
          : "Ocorreu um erro ao carregar os dados."
      );
    } finally {
      setCarregando(false);
    }
  }, []);

  useEffect(() => {
    carregarDados();
  }, [carregarDados]);

  async function adicionarOcorrencia(
    ocorrencia: Omit<Occ, "id" | "by" | "status">
  ) {
    const resposta = await fetch("/api/ocorrencias", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        aluno_id: ocorrencia.aluno_id,
        data_fato: ocorrencia.data_fato,
        horario: ocorrencia.horario,
        tipo: ocorrencia.tipo,
        item: ocorrencia.item,
        observacao: ocorrencia.observacao,
        registrado_por: "Usuário do protótipo",
        status: "Registrada",
      }),
    });

    const dados = await resposta.json().catch(() => ({}));

    if (!resposta.ok) {
      throw new Error(
        dados.error ??
          "A API ainda não permite gravar ocorrências. Precisamos configurá-la."
      );
    }

    await carregarDados();
    setPagina("Ocorrências");
  }

  const navegacao: { nome: Page; icone: string }[] = [
    { nome: "Dashboard", icone: "grid" },
    ...(role === "assistente" ? [{ nome: "Registrar ocorrência" as Page, icone: "plus" }] : []),
    { nome: "Alunos", icone: "users" },
    { nome: "Ocorrências", icone: "clipboard" },
  ];

  function navegar(destino: Page) {
    if (destino === "Registrar ocorrência" && role !== "assistente") return;
    setPagina(destino);
    setMenuAberto(false);
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800">
      <header className="sticky top-0 z-20 border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
          <button
            type="button"
            onClick={() => navegar("Dashboard")}
            className="flex items-center gap-3 text-left"
          >
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-blue-700 text-white">
              <Icon name="clipboard" />
            </span>
            <span>
              <span className="block font-bold text-slate-900">{APP_NAME}</span>
              <span className="block text-xs text-slate-500">{APP_TAGLINE}</span>
            </span>
          </button>

          <button
            type="button"
            onClick={() => setMenuAberto((aberto) => !aberto)}
            className="rounded-lg border border-slate-200 p-2 md:hidden"
            aria-label="Abrir menu"
          >
            <Icon name="grid" />
          </button>

          <nav className="hidden items-center gap-1 md:flex">
            {navegacao.map((item) => (
              <button
                key={item.nome}
                type="button"
                onClick={() => navegar(item.nome)}
                className={`flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition ${
                  pagina === item.nome
                    ? "bg-blue-50 text-blue-700"
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                <Icon name={item.icone} />
                {item.nome}
              </button>
            ))}
          </nav>
        </div>

        {menuAberto && (
          <nav className="space-y-1 border-t border-slate-100 p-3 md:hidden">
            {navegacao.map((item) => (
              <button
                key={item.nome}
                type="button"
                onClick={() => navegar(item.nome)}
                className={`flex w-full items-center gap-2 rounded-lg px-3 py-3 text-left text-sm font-medium ${
                  pagina === item.nome
                    ? "bg-blue-50 text-blue-700"
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                <Icon name={item.icone} />
                {item.nome}
              </button>
            ))}
          </nav>
        )}
      </header>

      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6 sm:py-8">
        {erro && (
          <div className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
            <span>{erro}</span>
            <Button variant="secondary" onClick={carregarDados}>
              Tentar novamente
            </Button>
          </div>
        )}

        {carregando ? (
          <Card>
            <p className="text-sm text-slate-500">Carregando dados do sistema...</p>
          </Card>
        ) : (
          <>
            {pagina === "Dashboard" && (
              <Dashboard
                alunos={alunos}
                ocorrencias={ocorrencias}
                onNavigate={navegar}
              />
            )}

            {pagina === "Registrar ocorrência" && (
              <OccurrenceForm onAdd={adicionarOcorrencia} />
            )}

            {pagina === "Alunos" && <Students />}

            {pagina === "Ocorrências" && (
              <Occurrences ocorrencias={ocorrencias} />
            )}
          </>
        )}

        <footer className="mt-10 border-t border-slate-200 py-5 text-center text-xs text-slate-500">
          SIGO-IFAM · Protótipo acadêmico · Proteja os dados dos estudantes.
        </footer>
      </main>
    </div>
  );
}

export default function Home() {
  const { data: session, status } = useSession();

  if (status === "loading") {
    return <div className="mx-auto max-w-md py-10"><Card><p className="text-center text-slate-600">Verificando seu acesso...</p></Card></div>;
  }

  if (!session?.user?.email || !session.user.role) {
    return <Login />;
  }

  return (
    <div>
      <div className="mx-auto flex max-w-6xl justify-end px-4 pt-4">
        <div className="flex items-center gap-3 text-sm">
          <span className="text-slate-600">{session.user.name || session.user.email} · {session.user.role === "dep" ? "DEP" : "Assistente de Alunos"}</span>
          {session.user.role === "dep" && <a className="font-semibold text-green-700 underline" href="/usuarios">Gerenciar usuários</a>}
          <button className="rounded-lg border px-3 py-2" onClick={() => signOut({ callbackUrl: "/" })}>Sair</button>
        </div>
      </div>
      <AppShell role={session.user.role} />
    </div>
  );
}
