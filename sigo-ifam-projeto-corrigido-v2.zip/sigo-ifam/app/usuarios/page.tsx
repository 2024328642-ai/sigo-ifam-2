"use client";

import { FormEvent, useEffect, useState } from "react";
import { signIn, signOut, useSession } from "next-auth/react";

type Usuario = { id: string; nome: string; email: string; perfil: string; ativo: string };

export default function UsuariosPage() {
  const { data: session, status } = useSession();
  const [usuarios, setUsuarios] = useState<Usuario[]>([]);
  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [perfil, setPerfil] = useState("Assistente de Alunos");
  const [mensagem, setMensagem] = useState("");
  const [erro, setErro] = useState("");
  const [carregando, setCarregando] = useState(false);

  async function carregar() {
    const res = await fetch("/api/usuarios");
    const data = await res.json();
    if (!res.ok) throw new Error(data.erro || "Não foi possível carregar usuários.");
    setUsuarios(data.usuarios || []);
  }

  useEffect(() => {
    if (session?.user?.role === "dep") carregar().catch((e) => setErro(e.message));
  }, [session?.user?.role]);

  async function cadastrar(e: FormEvent) {
    e.preventDefault();
    setErro("");
    setMensagem("");
    setCarregando(true);
    try {
      const res = await fetch("/api/usuarios", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nome, email, perfil }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.erro || "Não foi possível cadastrar.");
      setMensagem(data.mensagem);
      setNome("");
      setEmail("");
      setPerfil("Assistente de Alunos");
      await carregar();
    } catch (e) {
      setErro(e instanceof Error ? e.message : "Erro inesperado.");
    } finally {
      setCarregando(false);
    }
  }

  if (status === "loading") return <main className="mx-auto max-w-3xl p-8">Verificando acesso...</main>;
  if (!session?.user?.email) {
    return <main className="mx-auto max-w-md p-8"><h1 className="mb-4 text-2xl font-bold">Gerenciar usuários</h1><p className="mb-4">Entre com a conta Google autorizada do DEP.</p><button className="rounded-lg bg-green-700 px-4 py-3 font-semibold text-white" onClick={() => signIn("google", { callbackUrl: "/usuarios" })}>Entrar com Google</button></main>;
  }
  if (session.user.role !== "dep") {
    return <main className="mx-auto max-w-2xl p-8"><h1 className="mb-3 text-2xl font-bold">Acesso negado</h1><p>Somente usuários autorizados do DEP podem gerenciar cadastros.</p><a className="mt-4 inline-block underline" href="/">Voltar ao sistema</a></main>;
  }

  return (
    <main className="mx-auto max-w-5xl space-y-6 p-6 md:p-10">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <div><p className="text-sm font-semibold uppercase tracking-wide text-green-700">SIGO-IFAM</p><h1 className="mt-1 text-2xl font-bold">Gerenciar usuários</h1><p className="mt-1 text-sm text-slate-600">Cadastre contas autorizadas na aba Usuarios do Google Sheets.</p></div>
        <div className="flex gap-3"><a className="rounded-lg border px-4 py-2" href="/">Voltar</a><button className="rounded-lg border px-4 py-2" onClick={() => signOut({ callbackUrl: "/" })}>Sair</button></div>
      </header>

      <section className="rounded-xl border bg-white p-5 shadow-sm">
        <h2 className="mb-4 text-lg font-bold">Novo cadastro</h2>
        <form onSubmit={cadastrar} className="grid gap-4 md:grid-cols-2">
          <label className="grid gap-1 text-sm font-medium">Nome completo<input className="rounded-lg border px-3 py-2 font-normal" value={nome} onChange={(e) => setNome(e.target.value)} maxLength={120} required /></label>
          <label className="grid gap-1 text-sm font-medium">E-mail Google institucional<input className="rounded-lg border px-3 py-2 font-normal" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required /></label>
          <label className="grid gap-1 text-sm font-medium md:col-span-2">Perfil<select className="rounded-lg border px-3 py-2 font-normal" value={perfil} onChange={(e) => setPerfil(e.target.value)}><option value="Assistente de Alunos">Assistente de Alunos</option><option value="DEP">DEP — acesso administrativo</option></select></label>
          <p className="text-xs text-slate-500 md:col-span-2">O perfil DEP concede acesso administrativo. Cadastre-o somente para pessoas autorizadas.</p>
          <button disabled={carregando} className="rounded-lg bg-green-700 px-4 py-3 font-semibold text-white disabled:opacity-50 md:col-span-2">{carregando ? "Salvando..." : "Cadastrar usuário"}</button>
        </form>
        {mensagem && <p className="mt-4 rounded-lg bg-green-50 p-3 text-sm text-green-800">{mensagem}</p>}
        {erro && <p className="mt-4 rounded-lg bg-red-50 p-3 text-sm text-red-800">{erro}</p>}
      </section>

      <section className="rounded-xl border bg-white p-5 shadow-sm">
        <h2 className="mb-4 text-lg font-bold">Usuários cadastrados</h2>
        <div className="overflow-x-auto"><table className="w-full text-left text-sm"><thead><tr className="border-b text-slate-500"><th className="p-2">Nome</th><th className="p-2">E-mail</th><th className="p-2">Perfil</th><th className="p-2">Ativo</th></tr></thead><tbody>{usuarios.map((u) => <tr className="border-b last:border-0" key={u.id || u.email}><td className="p-2">{u.nome}</td><td className="p-2">{u.email}</td><td className="p-2">{u.perfil}</td><td className="p-2">{u.ativo}</td></tr>)}</tbody></table></div>
      </section>
    </main>
  );
}
