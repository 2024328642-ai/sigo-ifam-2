
import { NextResponse } from "next/server";
import { google } from "googleapis";
import path from "node:path";

export const runtime = "nodejs";

export async function GET() {
  // Esta rota serve apenas para testes locais.
  if (process.env.NODE_ENV !== "development") {
    return NextResponse.json(
      { erro: "Rota disponível apenas em desenvolvimento." },
      { status: 404 }
    );
  }

  try {
    const credentialsPath =
      process.env.GOOGLE_APPLICATION_CREDENTIALS;
    const spreadsheetId =
      process.env.GOOGLE_SHEETS_SPREADSHEET_ID;

    if (!credentialsPath || !spreadsheetId) {
      return NextResponse.json(
        { erro: "Variáveis de ambiente não configuradas." },
        { status: 500 }
      );
    }

    const auth = new google.auth.GoogleAuth({
      keyFile: path.resolve(process.cwd(), credentialsPath),
      scopes: [
        "https://www.googleapis.com/auth/spreadsheets.readonly",
      ],
    });

    const sheets = google.sheets({
      version: "v4",
      auth,
    });

    const resposta = await sheets.spreadsheets.get({
      spreadsheetId,
      fields: "properties.title,sheets.properties.title",
    });

    return NextResponse.json({
      conectado: true,
      planilha: resposta.data.properties?.title ?? "Sem título",
      abas:
        resposta.data.sheets?.map(
          (aba) => aba.properties?.title
        ) ?? [],
    });
  } catch (erro) {
    // Detalhes ficam no terminal, não na resposta ao navegador.
    console.error("Falha ao testar Google Sheets:", erro);

    return NextResponse.json(
      {
        conectado: false,
        erro: "Não foi possível acessar a planilha. Confira o terminal.",
      },
      { status: 500 }
    );
  }
}
