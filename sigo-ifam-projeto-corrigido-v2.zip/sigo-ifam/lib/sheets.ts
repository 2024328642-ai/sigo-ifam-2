import { google } from "googleapis";
import path from "node:path";

export type Usuario = {
  id: string;
  nome: string;
  email: string;
  perfil: string;
  ativo: string;
};

export function getSheets() {
  const credentialsPath = process.env.GOOGLE_APPLICATION_CREDENTIALS;
  const spreadsheetId = process.env.GOOGLE_SHEETS_SPREADSHEET_ID;
  if (!credentialsPath || !spreadsheetId) {
    throw new Error("Configuração do Google Sheets ausente.");
  }
  const auth = new google.auth.GoogleAuth({
    keyFile: path.resolve(process.cwd(), credentialsPath),
    scopes: ["https://www.googleapis.com/auth/spreadsheets"],
  });
  return { sheets: google.sheets({ version: "v4", auth }), spreadsheetId };
}

export function emailNormalizado(email: string) {
  return email.trim().toLowerCase();
}

export function ativoSim(valor: string) {
  return ["sim", "ativo", "true", "1", "yes"].includes(
    valor.trim().toLowerCase()
  );
}

export function perfilNormalizado(perfil: string): "assistente" | "dep" | null {
  const p = perfil.trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  if (p === "dep" || p === "administrador" || p === "admin") return "dep";
  if (p === "assistente" || p === "assistente de alunos" || p === "inspetor" || p === "assistente/inspetor") return "assistente";
  return null;
}

export async function buscarUsuarioPorEmail(email: string): Promise<Usuario | null> {
  const { sheets, spreadsheetId } = getSheets();
  const response = await sheets.spreadsheets.values.get({
    spreadsheetId,
    range: "Usuarios!A1:E",
  });
  const rows = response.data.values ?? [];
  const [, ...users] = rows;
  const target = emailNormalizado(email);
  const row = users.find((r) => emailNormalizado(String(r[2] ?? "")) === target);
  if (!row) return null;
  return {
    id: String(row[0] ?? ""),
    nome: String(row[1] ?? ""),
    email: emailNormalizado(String(row[2] ?? "")),
    perfil: String(row[3] ?? ""),
    ativo: String(row[4] ?? ""),
  };
}
