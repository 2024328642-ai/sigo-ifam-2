import type { NextAuthOptions } from "next-auth";
import GoogleProvider from "next-auth/providers/google";
import { ativoSim, buscarUsuarioPorEmail, perfilNormalizado } from "@/lib/sheets";

export const authOptions: NextAuthOptions = {
  session: { strategy: "jwt", maxAge: 60 * 60 * 8 },
  pages: { signIn: "/" },
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID ?? "",
      clientSecret: process.env.GOOGLE_CLIENT_SECRET ?? "",
      authorization: { params: { prompt: "select_account" } },
    }),
  ],
  callbacks: {
    async signIn({ user, account, profile }) {
      if (account?.provider !== "google" || !user.email) return false;
      const googleProfile = profile as { email_verified?: boolean };
      if (googleProfile.email_verified !== true) return false;
      try {
        const registered = await buscarUsuarioPorEmail(user.email);
        return Boolean(registered && ativoSim(registered.ativo) && perfilNormalizado(registered.perfil));
      } catch (error) {
        console.error("Falha ao validar usuário no Sheets:", error);
        return false;
      }
    },
    async jwt({ token, user, account }) {
      if (token.email) {
        try {
          const registered = await buscarUsuarioPorEmail(String(token.email));
          if (registered && ativoSim(registered.ativo)) {
            const role = perfilNormalizado(registered.perfil);
            if (role) {
              token.role = role;
              token.userId = registered.id;
              token.displayName = registered.nome || token.name || token.email;
            } else {
              token.role = undefined;
            }
          } else {
            token.role = undefined;
          }
        } catch (error) {
          console.error("Falha ao atualizar perfil do usuário:", error);
          token.role = undefined;
        }
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        (session.user as typeof session.user & { role?: string; userId?: string }).role =
          typeof token.role === "string" ? token.role : undefined;
        (session.user as typeof session.user & { userId?: string }).userId =
          typeof token.userId === "string" ? token.userId : undefined;
        if (typeof token.displayName === "string") session.user.name = token.displayName;
      }
      return session;
    },
  },
};
